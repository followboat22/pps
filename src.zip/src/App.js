import React from "react";
import Header from "./components/Header";
import Home from "./components/Home";
import Chapter from "./components/Chapter";
import Roadmap from "./components/Roadmap";
import Collapse from "./components/Collapse";
import Team from "./components/Team";
import Footer from "./components/Footer";

import "./App.css";

function App() {
  return (
    <>
      <Header />
      <Home />
      <Chapter />
      <Roadmap />
      <Collapse />
      <Team />
      <Footer />
    </>
  );
}
export default App;
