import React from "react";
import Swiper from "swiper";
import "swiper/swiper-bundle.min.css";
import "swiper/swiper.min.css";
import "./slider.css";

export default function Slider() {
  React.useEffect(() => {
    var swiper = new Swiper(".swiper-container.two", {
      pagination: true,
      effect: "coverflow",
      loop: true,
      centeredSlides: true,
      slidesPerView: "auto",
      coverflowEffect: {
        rotate: 0,
        stretch: 100,
        depth: 150,
        modifier: 1.5,
        slideShadows: false,
      },
    });
  }, []);
  return (
    <div class="swiper-container two">
      <div class="swiper-wrapper">
        <div class="swiper-slide">
          <div class="slider-image">
            <img
              src="//demo.xpeedstudio.com/wp/appscraft/demo2/wp-content/uploads/sites/2/2017/09/blue-screenshort-slider-img-5-1.png"
              alt="slide 1"
            />
          </div>
        </div>
        <div class="swiper-slide">
          <div class="slider-image">
            <img
              src="//demo.xpeedstudio.com/wp/appscraft/demo2/wp-content/uploads/sites/2/2017/09/blue-screenshort-slider-img-4-1.png"
              alt="slide 2"
            />
          </div>
        </div>
        <div class="swiper-slide">
          <div class="slider-image">
            <img
              src="//demo.xpeedstudio.com/wp/appscraft/demo2/wp-content/uploads/sites/2/2017/09/blue-screenshort-slider-img-2-1.png"
              alt="slide 3"
            />
          </div>
        </div>
        <div class="swiper-slide">
          <div class="slider-image">
            <img
              src="//demo.xpeedstudio.com/wp/appscraft/demo2/wp-content/uploads/sites/2/2017/09/blue-screenshort-slider-img-1-1.png"
              alt="slide 4"
            />
          </div>
        </div>
        {/* <!-- Add Pagination --> */}
      </div>
      <div class="swiper-pagination"></div>
    </div>
  );
}
