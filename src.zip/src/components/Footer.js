import React from "react";
import Fade from "react-reveal/Fade";

function Footer() {
  return (
    <Fade bottom>
      <footer className="Footer">
        <div className="container">
          <div>
            <a href="#">
              <img src="/Images/logo.png" className="img-fluid" />
            </a>
          </div>
          <h1>
            Join The{" "}
            <span style={{ backgroundImage: "linear-gradient(to bottom left,#443A75, #D46BC4)" }}>Society</span>
          </h1>
          <p>
            5,000 Peaceful Prophets Focused on Spreading Peace & Tranquillity on Solana Blockchain
          </p>
          <div>
            <a href="https://twitter.com/PeacfulProphets" className="socilLinks">
              <i className="fab fa-twitter"></i>
            </a>
            <a href="https://discord.gg/SdFw4TSMGs" className="socilLinks">
              <i className="fab fa-discord"></i>
            </a>
          </div>
          <p>All rights reserved</p>
        </div>
      </footer>
    </Fade>
  );
}

export default Footer;
