import React from "react";
import Fade from "react-reveal/Fade";

const Roadmap = () => (
  <section className="Roadmap" id="Roadmap">
    <div className="container">
      <h1 className="mt-0" style={{ backgroundImage: "linear-gradient(to bottom left,#443A75, #D46BC4)" }}>
        Roadmap
      </h1>
      <div className="roadmapContent">
        <div
          className="varticalLine"
          style={{ backgroundImage: "linear-gradient(to top right,#443A75, #D46BC4)" }}
        ></div>
        <Fade left>
          <div className="row">
            <div className="col-md-6">
              <div className="d-block d-lg-flex ">
                <h2 className="d-xl-none">10%</h2>
                <div
                  className="roadmap_textbox"
                  style={{ backgroundImage: "linear-gradient(to top right,#fbc2eb, #a6c1ee)" }}
                >
                  <p>
                    The creation of the Peaceful Prophet Society art and social media along with a massive influencer marketing campaign with accounts from all over the world! We will also host giveaways and contests to spread awareness about our great society.
                  </p>
                </div>
                <h2 className="subText">10%</h2>
              </div>
            </div>
            <div className="col-md-6"></div>
          </div>
        </Fade>
        <Fade right>
          <div className="row flex-md-row-reverse">
            <div className="col-md-6">
              <div className="d-block d-lg-flex">
                <h2 className="">20%</h2>
                <div
                  className="roadmap_textbox"
                  style={{ backgroundImage: "linear-gradient(to top right,#fbc2eb, #a6c1ee)" }}
                >
                  <p>
                    In February, 5,000 Peaceful Prophets will be available for minting. Which will include 3,900 “Peaceful" Prophets, 1,000 “Oracle" Prophets and 100 “Chosen One" Prophets to take over the Solana Blockchain.
                  </p>
                </div>
              </div>
            </div>
            <div className="col-md-6"></div>
          </div>
        </Fade>
        <Fade left>
          <div className="row">
            <div className="col-md-6">
              <div className="d-block d-lg-flex ">
                <h2 className="d-xl-none">40%</h2>
                <div
                  className="roadmap_textbox"
                  style={{ backgroundImage: "linear-gradient(to top right,#fbc2eb, #a6c1ee)" }}
                >
                  <p>
                    After sell out we will start collecting 80% of the secondary sale royalties and preparing to give back to “Chosen One" Prophets at the start of every month. We will also begin artwork on the Baby Prophet collection that will be airdropped to all “Oracle" Prophet holders.
                  </p>
                </div>
                <h2 className="subText">40%</h2>
              </div>
            </div>
            <div className="col-md-6"></div>
          </div>
        </Fade>
        <Fade right>
          <div className="row flex-md-row-reverse">
            <div className="col-md-6">
              <div className="d-block d-lg-flex">
                <h2 className="">60%</h2>
                <div
                  className="roadmap_textbox"
                  style={{ backgroundImage: "linear-gradient(to top right,#fbc2eb, #a6c1ee)" }}
                >
                  <p>
                    The Society of Peaceful Prophets have been fully released and are ready to take over. We will start ramping things up and use efficient marketing tools to spread awareness about our society. As well as donating a portion of mint profits to St. Judes Children Hospital, so everyone can prophesize their own future.
                  </p>
                </div>
              </div>
            </div>
            <div className="col-md-6"></div>
          </div>
        </Fade>
        <Fade left>
          <div className="row">
            <div className="col-md-6">
              <div className="d-block d-lg-flex ">
                <h2 className="d-xl-none">80%</h2>
                <div
                  className="roadmap_textbox"
                  style={{ backgroundImage: "linear-gradient(to top right,#fbc2eb, #a6c1ee)" }}
                >
                  <p>
                    Monthly airdrops of secondary sale royalties to “Chosen One” Prophet holders begin. Along with additional giveaways exclusive for holders where they can win “Oracle” and “Chosen One” Prophets.
                  </p>
                </div>
                <h2 className="subText">80%</h2>
              </div>
            </div>
            <div className="col-md-6"></div>
          </div>
        </Fade>
        <Fade right>
          <div className="row flex-md-row-reverse">
            <div className="col-md-6">
              <div className="d-block d-lg-flex">
                <h2 className="">100%</h2>
                <div
                  className="roadmap_textbox"
                  style={{ backgroundImage: "linear-gradient(to top right,#fbc2eb, #a6c1ee)" }}
                >
                  <p>
                    The Baby Prophet collection is completed and we begin airdrops to all “Oracle" Prophet holders.
                  </p>
                </div>
              </div>
            </div>
            <div className="col-md-6"></div>
          </div>
        </Fade>
      </div>
    </div>
  </section>
);

export default Roadmap;
