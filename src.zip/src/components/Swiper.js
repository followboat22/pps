import React from "react";
import Swiper from "react-id-swiper";
// import "swiper/swiper-bundle.min.css";
// import "swiper/swiper.min.css";

const Slider = ({ settings, children }) => {
  const params = {
    pagination: {
      el: ".swiper-pagination",
      clickable: true,
    },
    navigation: false,
    className: ".swiper-container .two",
    ...settings,
  };

  return <Swiper {...params}>{children}</Swiper>;
};

export default Slider;
