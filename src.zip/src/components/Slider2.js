import React from "react";
import SwiperCore, { EffectCoverflow, Pagination } from "swiper";
// Direct React component imports
// import { Swiper, SwiperSlide } from "swiper/react/swiper-react.js";
import { Swiper, SwiperSlide } from "swiper/react";
import Slider from "./Swiper";

// Import Swiper styles
// import "swiper/css";
// import "swiper/css/effect-coverflow";
// import "swiper/css/pagination";

import "./slider.css";

// install Swiper modules
SwiperCore.use([EffectCoverflow, Pagination]);

export default function Slider2() {
  const settings = {
    effect: "coverflow",
    pagination: true,
    loop: true,
    centeredSlides: true,
    slidesPerView: 1,
    coverflowEffect: {
      rotate: 0,
      stretch: 50,
      depth: 200,
      modifier: 1.5,
      slideShadows: true,
    },
    className: "swiper-container two",
    breakpoints: {
      768: {
        slidesPerView: 3,
      },
      1280: {
        slidesPerView: 3,
      },
    },
  };
  const data = [...Array(10).keys()];
  return (
    // <Slider settings={settings}>
    //   {data.map((item) => (
    //     <img src="https://picsum.photos/200/300" key={item} alt="swipe" />
    //   ))}
    // </Slider>
    <Swiper {...settings}>
      <SwiperSlide>
        <img src="https://i.postimg.cc/FRrq8yFM/21.png" />
      </SwiperSlide>
      <SwiperSlide>
        <img src="https://i.postimg.cc/jjsZSsVN/39.png" />
      </SwiperSlide>
      <SwiperSlide>
        <img src="https://i.postimg.cc/wB7FmwvT/4920.png" />
      </SwiperSlide>
      <SwiperSlide>
        <img src="https://i.postimg.cc/Zqcs8WPV/10.png" />
      </SwiperSlide>
      <SwiperSlide>
        <img src="https://i.postimg.cc/LhKVKSBJ/63.png" />
      </SwiperSlide>
      <SwiperSlide>
        <img src="https://i.postimg.cc/KvSVyhY7/4953.png" />
      </SwiperSlide>
    </Swiper>
  );
}
