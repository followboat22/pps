import React from "react";

import Fade from "react-reveal/Fade";

function Chapter() {
  return (
    <section className="Chapter" id="Tagline">
      <div className="container">
        <h1 className="titleHeading">
          The Start Of A{" "}
          <span style={{ backgroundImage: "linear-gradient(to bottom left, #443A75, #D46BC4)" }}>New Era</span>
        </h1>
        <Fade left>
          <div className="row align-items-center mt-5">
            <div className="offset-md-1 col-md-4 mt-5">
              <div className="frame1" style={{ backgroundImage: "url(/images/frame1.png)" }}>
                <img src="/images/intro.png" className="img-fluid" />
              </div>
            </div>
            <div className="col-md-6 mt-5">
              <div className="p-3">
                <h2>What is Peaceful Prophet Society?</h2>
                <p>
                The Peaceful Prophet Society is a collection of 5000 uniquely generated Prophets that are here to spread peace through the solona universe. Divided into 3 important ranks, that all have an important role to play with completing our mission. Each with different rewards and utility’s.
                </p>
              </div>
            </div>
          </div>
        </Fade>
        <Fade right>
          <div className="row align-items-center">
            <div className="offset-md-1 col-md-6 mt-5">
              <div className="p-3">
                <h2>Join The Society!</h2>
                <p>
                  When you bay a Prophet, you don’t just buy a CHARACTER or a piece of art. You are gaining access to a society whose benefits and offerings will increase over time. Your Prophet can serve as your digital identity, access exclusive to holders club where you can get exclusive call outs and whitelists for other good projects, free secondary projects, % of secondary sale royalties, and much more!
                </p>
              </div>
            </div>
            <div className="col-md-4 mt-5 text-start">
              <div className="frame1" style={{ backgroundImage: "url(/images/frame1.png)" }}>
                <img src="/images/news.png" className="img-fluid" />
              </div>
            </div>
          </div>
        </Fade>
      </div>
    </section>
  );
}

export default Chapter;
