import React from "react";
import Accordion from "react-bootstrap/Accordion";
import Fade from "react-reveal/Fade";

function Collapse() {
  const [activeFaq, setActiveFaq] = React.useState();
  return (
    <Fade bottom>
      <section
        className="Collapse"
        id="Faq"
        style={{
          background: "linear-gradient( 45deg,#fbc2eb,#b0c1ee,#ffa99f,#ebbc63)",
          backgroundSize: "400% 400%",
          animation: "gradient 7s ease infinite",
        }}
      >
        <div
          style={{
            background:
              "linear-gradient(133.22deg,rgba(39,39,42,0) 54.16%,#27272a 88.42%),linear-gradient(150.33deg,#27272a 10.29%,rgba(39,39,42,0) 62.09%),linear-gradient(180deg,#27272a,transparent 50%),linear-gradient(0deg,#27272a,rgba(33,33,33,0) 59.54%)",
          }}
        >
          <div className="container">
            <h1 className="mb-4">
              Project <span style={{ backgroundImage: "linear-gradient(to bottom left,#443A75, #D46BC4)" }}>FAQ's</span>
            </h1>
            <div className="row">
              <div className="col-md-8 mx-auto">
                <Accordion>
                  <Accordion.Item
                    eventKey="0"
                    style={{ border: activeFaq === 0 ? "2px solid #fbc2eb" : "" }}
                    onClick={() => setActiveFaq(0)}
                  >
                    <Accordion.Header>What is the Total Supply?</Accordion.Header>
                    <Accordion.Body>
                      5,000 Prophets will be able to purchase. These will be a collectors piece, Granting you access to the Peaceful Prophet Society.
                    </Accordion.Body>
                  </Accordion.Item>
                  <Accordion.Item
                    eventKey="1"
                    style={{ border: activeFaq === 1 ? "2px solid #fbc2eb" : "" }}
                    onClick={() => setActiveFaq(1)}
                  >
                    <Accordion.Header>When is the Release Date? </Accordion.Header>
                    <Accordion.Body>
                      Those willing to be apart of The Peaceful Prophet Society will be enlightened and able to do so on the 10th of
                      February 2022. Make sure you’re prepared for the drop my fellow Prophets!
                    </Accordion.Body>
                  </Accordion.Item>
                  <Accordion.Item
                    eventKey="2"
                    style={{ border: activeFaq === 2 ? "2px solid #fbc2eb" : "" }}
                    onClick={() => setActiveFaq(2)}
                  >
                    <Accordion.Header>How Many Can I Purchase?</Accordion.Header>
                    <Accordion.Body>
                      The maximum mint limit per person will be 50 Peaceful Prophets NFTs. Just purchasing one will ensure
                      you are one of the Peaceful Prophet members.
                    </Accordion.Body>
                  </Accordion.Item>
                  <Accordion.Item
                    eventKey="3"
                    style={{ border: activeFaq === 3 ? "2px solid #fbc2eb" : "" }}
                    onClick={() => setActiveFaq(3)}
                  >
                    <Accordion.Header>Is there Different Types of Rarity?</Accordion.Header>
                    <Accordion.Body>
                      The class system is one that has been embedded into The Peaceful Prophet Society. Rarity is one of the most
                      important features in this Society. The collection will range from common to chosen one.
                    </Accordion.Body>
                  </Accordion.Item>
                  <Accordion.Item
                    eventKey="4"
                    style={{ border: activeFaq === 4 ? "2px solid #fbc2eb" : "" }}
                    onClick={() => setActiveFaq(4)}
                  >
                    <Accordion.Header> What is the Utility of the Project? </Accordion.Header>
                    <Accordion.Body>
                      
                    </Accordion.Body>
                  </Accordion.Item>
                  <Accordion.Item
                    eventKey="5"
                    style={{ border: activeFaq === 5 ? "2px solid #fbc2eb" : "" }}
                    onClick={() => setActiveFaq(5)}
                  >
                    <Accordion.Header>What is the Mint Price?</Accordion.Header>
                    <Accordion.Body>The mint price to secure your place in the Peaceful Prophet Society is 2 SOL.</Accordion.Body>
                  </Accordion.Item>
                </Accordion>
              </div>
            </div>
          </div>
        </div>
      </section>
    </Fade>
  );
}

export default Collapse;
