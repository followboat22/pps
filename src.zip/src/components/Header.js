import React from "react";

function Header() {
  return (
    <header id="Header">
      <div className="container">
        <nav className="navbar navbar-expand-lg">
          <button
            className="navbar-toggler"
            type="button"
            data-bs-toggle="collapse"
            data-bs-target="#navbarSupportedContent"
            aria-controls="navbarSupportedContent"
            aria-expanded="false"
            aria-label="Toggle navigation"
          >
            <span className="navbar-toggler-icon">
              <i className="fas fa-bars"></i>
            </span>
          </button>
          <div className="collapse navbar-collapse" id="navbarSupportedContent">
            <ul className="navbar-nav">
              <li className="nav-item">
                <a className="nav-link" href="#">
                  <img src="/Images/logo.png" />
                </a>
              </li>
            </ul>
            <ul className="navbar-nav mx-auto">
              <li className="nav-item">
                <a className="nav-link" href="#Home">
                  Home
                </a>
              </li>
              <li className="nav-item">
                <a className="nav-link" href="#Tagline">
                  Tagline
                </a>
              </li>
              <li className="nav-item">
                <a className="nav-link" href="#Faq">
                  FAQ
                </a>
              </li>
              <li className="nav-item">
                <a className="nav-link" href="#Roadmap">
                  Roadmap
                </a>
              </li>
              <li className="nav-item">
                <a className="nav-link" href="#Team">
                  Team
                </a>
              </li>
            </ul>
          </div>
          <div>
            <a className="mintBtn" href="https://peacefulprophetsocietymint.com">
              <span>Mint Now</span> <i class="fas fa-long-arrow-alt-right"></i>
            </a>
          </div>
        </nav>
      </div>
    </header>
  );
}

export default Header;
