import React from "react";
import Fade from "react-reveal/Fade";

function Team() {
  return (
    <Fade bottom>
      <section className="Team" id="Team">
        <div className="container">
          <h1>
            Our <span style={{ backgroundImage: "linear-gradient(to bottom left,#443A75, #D46BC4)" }}>Team</span>
          </h1>
          <div className="row">
            <div className="col-md-4">
              <div className="cards">
                <img src="/images/team1.png" className="img-fluid" />
                <h2>Peaceful Master</h2>
              </div>
              <p>Artist</p>
            </div>
            <div className="col-md-4">
              <div className="cards">
                <img src="/images/team2.png" className="img-fluid" />
                <h2>Prophet Genie</h2>
              </div>
              <p>Founder</p>
            </div>
            <div className="col-md-4">
              <div className="cards">
                <img src="/images/team3.png" className="img-fluid" />
                <h2>Patient Wizard</h2>
              </div>
              <p>Developer</p>
            </div>
          </div>
        </div>
      </section>
    </Fade>
  );
}

export default Team;
