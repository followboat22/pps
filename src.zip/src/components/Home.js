import React from "react";
import Slider from "./Slider";
import Slider2 from "./Slider2";

function Home() {
  return (
    <section className="Home" id="Home" style={{ backgroundImage: "url(/images/bg-img.png)" }}>
      <div className="container">
        <img className="logo" src="/images/logo.png" />
        <div className="row">
          <div className="col-md-3 d-none  d-md-block">
          </div>
          <div className="col-md-6">
            <div className="heroContent">
              <div style={{marginBottom: "3em"}}>
                <h1>PEACEFUL PROPHET SOCIETY</h1>
                <p>5,000 PEACEFUL PROPHETS FOCUSED ON SPREADING PEACE AND TRANQUILLITY ON THE SOLANA BLOCKCHAIN</p>
              </div>
              <div className="action_btn" style={{ marginLeft: "-1.5em" }}>
                <a href="https://discord.gg/SdFw4TSMGs">
                  <span>Join community</span>
                </a>
                <a href="https://twitter.com/PeacfulProphets">
                  <span>Explore</span> <i class="fas fa-long-arrow-alt-right"></i>
                </a>
              </div>
            </div>
          </div>
        </div>
        {/* <Slider /> */}
        <div className="my-5">
          <Slider2 />
        </div>
      </div>
    </section>
  );
}

export default Home;
